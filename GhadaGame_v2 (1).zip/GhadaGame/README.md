# 🌸 Ghada & Yacine Adventure
**Kotlin + Android Studio | MVVM | API 24+ | ~5MB (no external assets)**

---

## 🚀 Open in Android Studio

```
1. Unzip GhadaGame_v2.zip
2. Android Studio → File → Open → select GhadaGame folder
3. Wait for Gradle sync
4. Run ▶ on device / emulator (API 24+)
```

---

## 🎮 Gameplay

| Action | Control |
|---|---|
| Move Ghada left | ◀ button (hold) or swipe left |
| Move Ghada right | ▶ button (hold) or swipe right |
| Pause | ⏸ top-right |
| Meet Yacine | Get close to him for +5 bonus! |

**Avoid** 3 obstacle types:
- 🔴 **Block** — plain square
- 🟠 **Spike** — triangle that drops
- 💣 **Bomb** — circular bomb with fuse

Every **10 obstacles dodged** = level up (faster + new background theme)

---

## 🖼 Replace Character Sprites

**Ghada:**
1. Add `ghada_sprite.png` → `res/drawable/`
2. In `activity_main.xml`: `android:src="@drawable/ghada_sprite"` on `ivGhada`
3. In `GameView.kt`: uncomment `ghadaBitmap = BitmapFactory...` in `loadBitmaps()`

**Yacine:**
1. Add `yacine_sprite.png` → `res/drawable/`
2. In `activity_main.xml`: `android:src="@drawable/yacine_sprite"` on `ivYacine`
3. In `GameView.kt`: uncomment `yacineBitmap = BitmapFactory...`

---

## 🔊 Add Sound Effects

Place `.ogg` files in `res/raw/`:
```
res/raw/sfx_dodge.ogg     ← obstacle avoided
res/raw/sfx_hit.ogg       ← player dies
res/raw/sfx_bonus.ogg     ← Yacine bonus collected
res/raw/sfx_levelup.ogg   ← level changed
```
Then in `SoundManager.kt` uncomment the 4 `soundPool!!.load()` lines.

---

## ⚙️ Tune Difficulty

Edit **`GameConstants.kt`**:
```kotlin
BASE_SPEED_DP       = 6f     // starting obstacle speed
SPEED_INC_DP        = 1.8f   // speed added per level
OBSTACLES_PER_LEVEL = 10     // score per level-up
YACINE_APPEAR_EVERY = 20     // obstacles before Yacine appears
YACINE_BONUS_SCORE  = 5      // bonus points for meeting Yacine
MAX_LEVEL           = 8      // max difficulty cap
```

---

## 📁 File Map

```
GhadaGame/
├── app/src/main/java/com/example/ghadagame/
│   ├── GameConstants.kt       ← all tunable values
│   ├── Models.kt              ← GameState + Obstacle (MVVM Model)
│   ├── GameViewModel.kt       ← all game logic (MVVM ViewModel)
│   ├── GameView.kt            ← Canvas renderer (MVVM View)
│   ├── SoundManager.kt        ← sound effects (stubs ready to fill)
│   ├── MainActivity.kt        ← main menu
│   ├── GameActivity.kt        ← game screen + input
│   ├── SettingsActivity.kt    ← sound/music toggles
│   └── GameOverActivity.kt    ← score summary
└── res/
    ├── layout/                ← 4 XML layouts
    ├── drawable/              ← shapes, buttons, placeholders
    └── values/                ← strings, colors, styles
```

---

## 🎨 8 Level Backgrounds

| Level | Theme | Colors |
|---|---|---|
| 1 | 🌲 Forest | Deep green |
| 2 | 🏙 City | Dark navy |
| 3 | ☁️ Sky | Light blue |
| 4 | 🌅 Sunset | Orange/gold |
| 5 | 🚀 Space | Deep purple |
| 6 | 🔴 Crimson | Red gradient |
| 7 | 🌊 Ocean | Teal |
| 8 | 🔥 Fire | Orange-red |
