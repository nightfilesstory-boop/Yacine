package com.ghadagame.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.animation.AnimationUtils
import androidx.appcompat.app.AppCompatActivity
import com.ghadagame.app.R
import com.ghadagame.app.databinding.ActivityMainBinding

/**
 * Main Menu Screen.
 *
 * Shows:
 *  • Animated Ghada avatar (placeholder drawable)
 *  • Game title
 *  • START button → GameActivity
 *  • Best score (saved in SharedPreferences)
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Load and display best score
        val prefs = getSharedPreferences("ghada_prefs", MODE_PRIVATE)
        val best = prefs.getInt("best_score", 0)
        binding.tvBestScore.text = "🏆 Best: $best"

        // Bounce animation on Ghada avatar
        val bounce = AnimationUtils.loadAnimation(this, R.anim.bounce)
        binding.ivGhada.startAnimation(bounce)

        // Pulse animation on start button
        val pulse = AnimationUtils.loadAnimation(this, R.anim.pulse)
        binding.btnStart.startAnimation(pulse)

        // Start game
        binding.btnStart.setOnClickListener {
            binding.btnStart.clearAnimation()
            startActivity(Intent(this, GameActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh best score when returning from game
        val prefs = getSharedPreferences("ghada_prefs", MODE_PRIVATE)
        val best = prefs.getInt("best_score", 0)
        binding.tvBestScore.text = "🏆 Best: $best"

        // Restart animations
        val bounce = AnimationUtils.loadAnimation(this, R.anim.bounce)
        binding.ivGhada.startAnimation(bounce)
    }
}
