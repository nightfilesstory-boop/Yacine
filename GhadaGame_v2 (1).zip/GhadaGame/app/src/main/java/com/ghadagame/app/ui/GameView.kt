package com.ghadagame.app.ui

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import com.ghadagame.app.viewmodel.GameState
import com.ghadagame.app.viewmodel.Obstacle
import kotlin.math.cos
import kotlin.math.sin

/**
 * Custom View that draws the entire game world on a Canvas.
 *
 * ─ What it draws ─────────────────────────────────────────────────
 *  • Gradient background (changes tint by level)
 *  • Ghada character (colorful circle + face + hair)
 *  • Falling obstacles (spiky red circles)
 *  • "PAUSED" overlay when paused
 *
 * ─ Game loop ─────────────────────────────────────────────────────
 * The view drives its own 60-fps loop via [android.view.Choreographer].
 * Each frame it calls [onTick] → ViewModel.tick() → observes state → invalidate().
 *
 * ─ Replace Ghada image ───────────────────────────────────────────
 * To use a custom image instead of the drawn placeholder:
 *   1. Put your PNG in res/drawable/ghada.png
 *   2. Uncomment the BitmapFactory block in drawGhada()
 *   3. Comment out the drawGhadaPlaceholder() call
 */
class GameView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    // ── Callback set by GameActivity ──────────────────────────────────────────
    var onTick: (() -> Unit)? = null
    var onSizeReady: ((Float, Float) -> Unit)? = null

    // ── Latest state pushed from ViewModel ───────────────────────────────────
    var gameState: GameState? = null
        set(value) {
            field = value
            invalidate()
        }

    // ── Paints ────────────────────────────────────────────────────────────────
    private val bgPaint = Paint()
    private val ghadaSkinPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FDBCB4") }
    private val ghadaHairPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1A0A00") }
    private val ghadaEyePaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#2C1810") }
    private val ghadaDressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#C71585") }
    private val ghadaSmilePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8B0000")
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }
    private val obstaclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FF3333") }
    private val obstacleShadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#99000000") }
    private val starPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FFFFFF55") }
    private val pausePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#AA000000")
        textSize = 120f
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val overlayPaint = Paint().apply { color = Color.parseColor("#88000000") }

    // ── Gradient backgrounds per level ────────────────────────────────────────
    private val levelColors = listOf(
        intArrayOf(Color.parseColor("#1A237E"), Color.parseColor("#283593")), // Lvl 1 – deep blue night
        intArrayOf(Color.parseColor("#1B5E20"), Color.parseColor("#2E7D32")), // Lvl 2 – green forest
        intArrayOf(Color.parseColor("#4A148C"), Color.parseColor("#6A1B9A")), // Lvl 3 – purple dusk
        intArrayOf(Color.parseColor("#B71C1C"), Color.parseColor("#C62828")), // Lvl 4 – red danger
        intArrayOf(Color.parseColor("#E65100"), Color.parseColor("#F57C00"))  // Lvl 5+ – extreme orange
    )

    // ── Stars (decorative background dots) ────────────────────────────────────
    private data class Star(val x: Float, val y: Float, val r: Float)
    private val stars = mutableListOf<Star>()

    // ── Choreographer-based game loop ─────────────────────────────────────────
    private val choreographer = android.view.Choreographer.getInstance()
    private var loopRunning = false
    private val frameCallback = object : android.view.Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            onTick?.invoke()
            if (loopRunning) choreographer.postFrameCallback(this)
        }
    }

    fun startLoop() {
        if (!loopRunning) {
            loopRunning = true
            choreographer.postFrameCallback(frameCallback)
        }
    }

    fun stopLoop() {
        loopRunning = false
        choreographer.removeFrameCallback(frameCallback)
    }

    // ── Size change ───────────────────────────────────────────────────────────
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        onSizeReady?.invoke(w.toFloat(), h.toFloat())
        // Seed decorative stars
        stars.clear()
        repeat(60) {
            stars.add(Star(
                x = (Math.random() * w).toFloat(),
                y = (Math.random() * h * 0.7f).toFloat(),
                r = (1 + Math.random() * 3).toFloat()
            ))
        }
    }

    // ── Main draw ─────────────────────────────────────────────────────────────
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val state = gameState ?: return
        val W = width.toFloat()
        val H = height.toFloat()

        drawBackground(canvas, W, H, state.level)
        drawObstacles(canvas, state.obstacles)
        drawGhada(canvas, state.ghadaX, H * 0.80f, W * 0.07f)

        if (state.isPaused) drawPauseOverlay(canvas, W, H)
    }

    // ── Background ────────────────────────────────────────────────────────────
    private fun drawBackground(canvas: Canvas, W: Float, H: Float, level: Int) {
        val idx = (level - 1).coerceIn(0, levelColors.lastIndex)
        val colors = levelColors[idx]
        val gradient = LinearGradient(0f, 0f, 0f, H, colors[0], colors[1], Shader.TileMode.CLAMP)
        bgPaint.shader = gradient
        canvas.drawRect(0f, 0f, W, H, bgPaint)

        // Draw stars
        stars.forEach { canvas.drawCircle(it.x, it.y, it.r, starPaint) }

        // Ground strip
        val groundPaint = Paint().apply { color = Color.parseColor("#1A0A00") }
        canvas.drawRect(0f, H * 0.88f, W, H, groundPaint)
    }

    // ── Ghada ─────────────────────────────────────────────────────────────────
    private fun drawGhada(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        /*
         * ── TO USE A CUSTOM IMAGE ──────────────────────────────────────────
         * Uncomment the code below and comment out the drawGhadaPlaceholder() call:
         *
         *   val bitmap = BitmapFactory.decodeResource(resources, R.drawable.ghada)
         *   val size = (radius * 2.5f).toInt()
         *   val scaled = Bitmap.createScaledBitmap(bitmap, size, size, true)
         *   canvas.drawBitmap(scaled, cx - size / 2f, cy - size / 2f, null)
         *   return
         */
        drawGhadaPlaceholder(canvas, cx, cy, radius)
    }

    /** Draws a cute cartoon-style Ghada character using only shapes. */
    private fun drawGhadaPlaceholder(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        // Shadow
        val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#44000000") }
        canvas.drawOval(RectF(cx - r * 0.9f, cy + r * 1.1f, cx + r * 0.9f, cy + r * 1.5f), shadowPaint)

        // Dress / body (trapezoid)
        val dressPath = Path().apply {
            moveTo(cx - r * 0.5f, cy + r * 0.3f)
            lineTo(cx + r * 0.5f, cy + r * 0.3f)
            lineTo(cx + r * 0.9f, cy + r * 2.0f)
            lineTo(cx - r * 0.9f, cy + r * 2.0f)
            close()
        }
        canvas.drawPath(dressPath, ghadaDressPaint)

        // Dress pattern – small dots
        val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FF69B4") }
        for (i in 0..3) {
            canvas.drawCircle(cx - r * 0.4f + i * r * 0.27f, cy + r * 1.1f, r * 0.06f, dotPaint)
        }

        // Arms
        val armPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = ghadaSkinPaint.color; strokeWidth = r * 0.25f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        canvas.drawLine(cx - r * 0.5f, cy + r * 0.6f, cx - r * 1.1f, cy + r * 1.3f, armPaint)
        canvas.drawLine(cx + r * 0.5f, cy + r * 0.6f, cx + r * 1.1f, cy + r * 1.3f, armPaint)

        // Neck
        val neckPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = ghadaSkinPaint.color }
        canvas.drawRect(cx - r * 0.18f, cy - r * 0.05f, cx + r * 0.18f, cy + r * 0.35f, neckPaint)

        // Head
        canvas.drawCircle(cx, cy - r * 0.3f, r, ghadaSkinPaint)

        // Hair – hijab style
        val hijabPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#2C1810") }
        val hijabPath = Path().apply {
            addArc(RectF(cx - r * 1.05f, cy - r * 1.4f, cx + r * 1.05f, cy + r * 0.4f), 180f, 180f)
            lineTo(cx + r * 1.05f, cy + r * 0.3f)
            lineTo(cx - r * 1.05f, cy + r * 0.3f)
            close()
        }
        canvas.drawPath(hijabPath, hijabPaint)

        // Eyes
        canvas.drawCircle(cx - r * 0.32f, cy - r * 0.35f, r * 0.12f, ghadaEyePaint)
        canvas.drawCircle(cx + r * 0.32f, cy - r * 0.35f, r * 0.12f, ghadaEyePaint)
        // Eye shine
        val shinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        canvas.drawCircle(cx - r * 0.28f, cy - r * 0.38f, r * 0.04f, shinePaint)
        canvas.drawCircle(cx + r * 0.36f, cy - r * 0.38f, r * 0.04f, shinePaint)

        // Smile
        ghadaSmilePaint.strokeWidth = r * 0.06f
        canvas.drawArc(
            RectF(cx - r * 0.28f, cy - r * 0.15f, cx + r * 0.28f, cy + r * 0.12f),
            10f, 160f, false, ghadaSmilePaint
        )

        // Nose (small dot)
        val nosePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E07060") }
        canvas.drawCircle(cx, cy - r * 0.12f, r * 0.06f, nosePaint)

        // Blush cheeks
        val blushPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#66FF8090") }
        canvas.drawOval(RectF(cx - r * 0.62f, cy - r * 0.2f, cx - r * 0.32f, cy), blushPaint)
        canvas.drawOval(RectF(cx + r * 0.32f, cy - r * 0.2f, cx + r * 0.62f, cy), blushPaint)

        // Legs
        val legPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1A0A00"); strokeWidth = r * 0.28f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        canvas.drawLine(cx - r * 0.3f, cy + r * 2.0f, cx - r * 0.3f, cy + r * 2.7f, legPaint)
        canvas.drawLine(cx + r * 0.3f, cy + r * 2.0f, cx + r * 0.3f, cy + r * 2.7f, legPaint)

        // Shoes
        val shoePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#8B0000") }
        canvas.drawOval(RectF(cx - r * 0.55f, cy + r * 2.6f, cx - r * 0.05f, cy + r * 2.9f), shoePaint)
        canvas.drawOval(RectF(cx + r * 0.05f, cy + r * 2.6f, cx + r * 0.55f, cy + r * 2.9f), shoePaint)
    }

    // ── Obstacles ─────────────────────────────────────────────────────────────
    private fun drawObstacles(canvas: Canvas, obstacles: List<Obstacle>) {
        obstacles.forEach { obs ->
            // Shadow
            canvas.drawCircle(obs.x + 6f, obs.y + 6f, obs.radius, obstacleShadowPaint)

            // Body
            canvas.drawCircle(obs.x, obs.y, obs.radius, obstaclePaint)

            // Spikes
            val spikePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#CC0000") }
            val spikePath = Path()
            val spikeCount = 8
            for (i in 0 until spikeCount) {
                val angle = Math.toRadians((i * 360.0 / spikeCount)).toFloat()
                val innerR = obs.radius * 0.8f
                val outerR = obs.radius * 1.35f
                val midAngle = Math.toRadians((i * 360.0 / spikeCount + 360.0 / spikeCount / 2)).toFloat()

                if (i == 0) spikePath.moveTo(obs.x + cos(angle) * outerR, obs.y + sin(angle) * outerR)
                else spikePath.lineTo(obs.x + cos(angle) * outerR, obs.y + sin(angle) * outerR)
                spikePath.lineTo(obs.x + cos(midAngle) * innerR, obs.y + sin(midAngle) * innerR)
            }
            spikePath.close()
            canvas.drawPath(spikePath, spikePaint)

            // Evil face on obstacle
            val eyeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
            canvas.drawCircle(obs.x - obs.radius * 0.28f, obs.y - obs.radius * 0.1f, obs.radius * 0.14f, eyeP)
            canvas.drawCircle(obs.x + obs.radius * 0.28f, obs.y - obs.radius * 0.1f, obs.radius * 0.14f, eyeP)
            val pupilP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
            canvas.drawCircle(obs.x - obs.radius * 0.28f, obs.y - obs.radius * 0.08f, obs.radius * 0.07f, pupilP)
            canvas.drawCircle(obs.x + obs.radius * 0.28f, obs.y - obs.radius * 0.08f, obs.radius * 0.07f, pupilP)
            val mouthP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = obs.radius * 0.08f }
            canvas.drawArc(RectF(obs.x - obs.radius * 0.3f, obs.y + obs.radius * 0.15f, obs.x + obs.radius * 0.3f, obs.y + obs.radius * 0.45f), 0f, 180f, false, mouthP)
        }
    }

    // ── Pause overlay ─────────────────────────────────────────────────────────
    private fun drawPauseOverlay(canvas: Canvas, W: Float, H: Float) {
        canvas.drawRect(0f, 0f, W, H, overlayPaint)
        canvas.drawText("⏸ PAUSED", W / 2f, H / 2f, pausePaint)
        val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 45f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("Tap Pause to resume", W / 2f, H / 2f + 90f, subPaint)
    }
}
