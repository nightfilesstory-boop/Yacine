package com.ghadagame.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.animation.AnimationUtils
import androidx.appcompat.app.AppCompatActivity
import com.ghadagame.app.R
import com.ghadagame.app.databinding.ActivityGameOverBinding

/**
 * Game Over screen.
 *
 * Displays:
 *  • Final score
 *  • Level reached
 *  • Best score from SharedPreferences
 *  • PLAY AGAIN → GameActivity
 *  • MENU → MainActivity
 */
class GameOverActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_SCORE = "extra_score"
        const val EXTRA_LEVEL = "extra_level"
    }

    private lateinit var binding: ActivityGameOverBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameOverBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val score = intent.getIntExtra(EXTRA_SCORE, 0)
        val level = intent.getIntExtra(EXTRA_LEVEL, 1)
        val prefs = getSharedPreferences("ghada_prefs", MODE_PRIVATE)
        val best  = prefs.getInt("best_score", 0)

        binding.tvFinalScore.text = "Score: $score"
        binding.tvLevelReached.text = "Level reached: $level"
        binding.tvBestScore.text = if (score >= best) "🏆 NEW BEST: $best!" else "🏆 Best: $best"

        // Animations
        val slideIn = AnimationUtils.loadAnimation(this, R.anim.slide_in_bottom)
        binding.cardScore.startAnimation(slideIn)

        val pulse = AnimationUtils.loadAnimation(this, R.anim.pulse)
        binding.btnPlayAgain.startAnimation(pulse)

        binding.btnPlayAgain.setOnClickListener {
            startActivity(Intent(this, GameActivity::class.java))
            finish()
        }

        binding.btnMenu.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            })
            finish()
        }
    }
}
