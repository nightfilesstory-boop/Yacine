package com.ghadagame.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.ghadagame.app.databinding.ActivityGameBinding
import com.ghadagame.app.viewmodel.GameViewModel

/**
 * GameActivity hosts the GameView canvas and the HUD (score, level, pause button).
 *
 * Architecture (MVVM):
 *   Activity (View) ←observes→ GameViewModel ←drives→ GameView
 *
 * Controls:
 *   ◀ LEFT button  → ViewModel.moveGhadaLeft()
 *   ▶ RIGHT button → ViewModel.moveGhadaRight()
 *   ⏸ PAUSE button → ViewModel.togglePause()
 *
 * Game ends when ViewModel.gameState.isGameOver == true
 * → navigates to GameOverActivity with the final score.
 */
class GameActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGameBinding
    private val viewModel: GameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupGameView()
        setupControls()
        observeGameState()
    }

    // ── GameView setup ────────────────────────────────────────────────────────

    private fun setupGameView() {
        // Tell ViewModel the screen size once the view is laid out
        binding.gameView.onSizeReady = { w, h ->
            viewModel.initScreen(w, h)
        }

        // Each frame: advance game logic
        binding.gameView.onTick = {
            viewModel.tick()
        }

        // Start the 60-fps loop
        binding.gameView.startLoop()
    }

    // ── Button controls ───────────────────────────────────────────────────────

    private fun setupControls() {
        // Left / Right movement — continuous while pressed
        binding.btnLeft.setOnTouchListener { _, event ->
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN,
                android.view.MotionEvent.ACTION_MOVE -> viewModel.moveGhadaLeft()
            }
            true
        }

        binding.btnRight.setOnTouchListener { _, event ->
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN,
                android.view.MotionEvent.ACTION_MOVE -> viewModel.moveGhadaRight()
            }
            true
        }

        // Pause
        binding.btnPause.setOnClickListener {
            viewModel.togglePause()
        }
    }

    // ── State observation ─────────────────────────────────────────────────────

    private fun observeGameState() {
        viewModel.gameState.observe(this) { state ->
            // Push latest state to the canvas
            binding.gameView.gameState = state

            // Update HUD
            binding.tvScore.text = "⭐ ${state.score}"
            binding.tvLevel.text  = "Level ${state.level}"
            binding.btnPause.text = if (state.isPaused) "▶" else "⏸"

            // Navigate to Game Over
            if (state.isGameOver) {
                binding.gameView.stopLoop()
                saveBestScore(state.score)

                val intent = Intent(this, GameOverActivity::class.java).apply {
                    putExtra(GameOverActivity.EXTRA_SCORE, state.score)
                    putExtra(GameOverActivity.EXTRA_LEVEL, state.level)
                }
                startActivity(intent)
                finish()
            }
        }
    }

    // ── Persist best score ────────────────────────────────────────────────────

    private fun saveBestScore(score: Int) {
        val prefs = getSharedPreferences("ghada_prefs", MODE_PRIVATE)
        val current = prefs.getInt("best_score", 0)
        if (score > current) prefs.edit().putInt("best_score", score).apply()
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onPause() {
        super.onPause()
        // Auto-pause when app goes to background
        val state = viewModel.gameState.value
        if (state != null && !state.isPaused && !state.isGameOver) {
            viewModel.togglePause()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        binding.gameView.stopLoop()
    }

    override fun onBackPressed() {
        // Pause on back press rather than quitting
        val state = viewModel.gameState.value
        if (state != null && !state.isGameOver) {
            viewModel.togglePause()
        } else {
            super.onBackPressed()
        }
    }
}
