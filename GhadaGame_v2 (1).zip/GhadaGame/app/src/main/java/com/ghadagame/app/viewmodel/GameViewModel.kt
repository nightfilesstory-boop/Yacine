package com.ghadagame.app.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

/**
 * Represents the entire game state at any point in time.
 * The GameView observes this to redraw the canvas.
 */
data class GameState(
    val score: Int = 0,
    val level: Int = 1,
    val ghadaX: Float = 0f,       // center X of Ghada (0..screenWidth)
    val obstacles: List<Obstacle> = emptyList(),
    val isGameOver: Boolean = false,
    val isPaused: Boolean = false,
    val elapsedSeconds: Int = 0
)

/**
 * A single falling obstacle on screen.
 * @param id     unique ID so the view can track it
 * @param x      center X position
 * @param y      center Y position (increases downward)
 * @param radius size of the obstacle circle
 * @param speed  pixels per game-tick this obstacle falls
 */
data class Obstacle(
    val id: Int,
    val x: Float,
    val y: Float,
    val radius: Float,
    val speed: Float
)

/**
 * MVVM ViewModel — holds all game logic.
 * GameActivity observes [gameState] and calls update methods.
 */
class GameViewModel : ViewModel() {

    // ── LiveData ──────────────────────────────────────────────────────────────
    private val _gameState = MutableLiveData(GameState())
    val gameState: LiveData<GameState> = _gameState

    // ── Internal mutable state ────────────────────────────────────────────────
    private var screenWidth: Float = 1080f
    private var screenHeight: Float = 1920f
    private var nextObstacleId: Int = 0
    private var ticksSinceLastSpawn: Int = 0
    private var ticksSinceLastSecond: Int = 0
    private var spawnIntervalTicks: Int = 60   // ticks between new obstacle spawns
    private var baseObstacleSpeed: Float = 12f // pixels per tick — increases with level

    /** Ghada radius used for collision detection (matches GameView drawing) */
    val ghadaRadius: Float get() = screenWidth * 0.07f

    /** Obstacle radius (matches GameView drawing) */
    private val obstacleRadius: Float get() = screenWidth * 0.06f

    // ── Initialisation ────────────────────────────────────────────────────────

    /**
     * Call once when the screen size is known (GameView.onSizeChanged).
     */
    fun initScreen(width: Float, height: Float) {
        screenWidth = width
        screenHeight = height
        _gameState.value = GameState(ghadaX = width / 2f)
    }

    // ── Controls ──────────────────────────────────────────────────────────────

    /**
     * Move Ghada left by [delta] pixels, clamped to screen edges.
     */
    fun moveGhadaLeft(delta: Float = screenWidth * 0.05f) {
        val state = _gameState.value ?: return
        if (state.isGameOver || state.isPaused) return
        val newX = (state.ghadaX - delta).coerceAtLeast(ghadaRadius)
        _gameState.value = state.copy(ghadaX = newX)
    }

    /**
     * Move Ghada right by [delta] pixels, clamped to screen edges.
     */
    fun moveGhadaRight(delta: Float = screenWidth * 0.05f) {
        val state = _gameState.value ?: return
        if (state.isGameOver || state.isPaused) return
        val newX = (state.ghadaX + delta).coerceAtMost(screenWidth - ghadaRadius)
        _gameState.value = state.copy(ghadaX = newX)
    }

    // ── Pause ─────────────────────────────────────────────────────────────────

    fun togglePause() {
        val state = _gameState.value ?: return
        if (state.isGameOver) return
        _gameState.value = state.copy(isPaused = !state.isPaused)
    }

    // ── Game loop tick ────────────────────────────────────────────────────────

    /**
     * Called every frame (~60 fps) from GameView's game loop.
     * Moves obstacles, spawns new ones, checks collisions, updates score/level.
     */
    fun tick() {
        val state = _gameState.value ?: return
        if (state.isPaused || state.isGameOver) return

        // ── Elapsed time & level progression ─────────────────────────────────
        ticksSinceLastSecond++
        var elapsedSeconds = state.elapsedSeconds
        if (ticksSinceLastSecond >= 60) {
            ticksSinceLastSecond = 0
            elapsedSeconds++
        }

        // Every 30 seconds → new level: faster obstacles, shorter spawn interval
        val newLevel = 1 + (elapsedSeconds / 30)
        if (newLevel != state.level) {
            baseObstacleSpeed = 12f + (newLevel - 1) * 3f
            spawnIntervalTicks = (60 - (newLevel - 1) * 8).coerceAtLeast(20)
        }

        // ── Move existing obstacles downward ──────────────────────────────────
        val movedObstacles = state.obstacles
            .map { it.copy(y = it.y + it.speed) }
            .filter { it.y - it.radius < screenHeight } // remove off-screen

        // ── Count newly off-screen obstacles as avoided (score ++) ────────────
        val offScreenCount = state.obstacles.count { obs ->
            obs.y - obs.radius >= screenHeight
        }
        val newScore = state.score + offScreenCount

        // ── Spawn new obstacle ────────────────────────────────────────────────
        ticksSinceLastSpawn++
        val spawnedObstacles = movedObstacles.toMutableList()
        if (ticksSinceLastSpawn >= spawnIntervalTicks) {
            ticksSinceLastSpawn = 0
            val margin = obstacleRadius + 10f
            val randomX = margin + Math.random().toFloat() * (screenWidth - 2 * margin)
            spawnedObstacles.add(
                Obstacle(
                    id = nextObstacleId++,
                    x = randomX,
                    y = -obstacleRadius,
                    radius = obstacleRadius,
                    speed = baseObstacleSpeed + (Math.random().toFloat() * 4f - 2f) // slight variance
                )
            )
        }

        // ── Collision detection ───────────────────────────────────────────────
        val ghadaY = screenHeight * 0.80f  // Ghada sits at 80% down the screen
        val collision = spawnedObstacles.any { obs ->
            val dx = obs.x - state.ghadaX
            val dy = obs.y - ghadaY
            val dist = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
            dist < (obs.radius + ghadaRadius * 0.85f) // 0.85 = slight forgiveness
        }

        // ── Publish new state ─────────────────────────────────────────────────
        _gameState.value = state.copy(
            score = newScore,
            level = newLevel,
            obstacles = spawnedObstacles,
            isGameOver = collision,
            elapsedSeconds = elapsedSeconds
        )
    }

    // ── Reset ─────────────────────────────────────────────────────────────────

    fun resetGame() {
        nextObstacleId = 0
        ticksSinceLastSpawn = 0
        ticksSinceLastSecond = 0
        baseObstacleSpeed = 12f
        spawnIntervalTicks = 60
        _gameState.value = GameState(ghadaX = screenWidth / 2f)
    }
}
