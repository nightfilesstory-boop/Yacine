package com.example.ghadagame

import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.ghadagame.databinding.ActivitySettingsBinding

/**
 * SettingsActivity.kt
 * ====================
 * Sound FX / Music toggles + Reset High Score.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val prefs    = getSharedPreferences(GameConstants.PREFS_NAME, MODE_PRIVATE)
        var soundOn  = prefs.getBoolean(GameConstants.KEY_SOUND_ON, true)
        var musicOn  = prefs.getBoolean(GameConstants.KEY_MUSIC_ON, true)

        fun refreshUI() {
            binding.btnSoundToggle.text       = if (soundOn) "ON"  else "OFF"
            binding.btnSoundToggle.background = getDrawable(if (soundOn) R.drawable.toggle_on else R.drawable.toggle_off)
            binding.btnMusicToggle.text       = if (musicOn) "ON"  else "OFF"
            binding.btnMusicToggle.background = getDrawable(if (musicOn) R.drawable.toggle_on else R.drawable.toggle_off)
        }

        refreshUI()

        binding.btnSoundToggle.setOnClickListener {
            soundOn = !soundOn
            prefs.edit().putBoolean(GameConstants.KEY_SOUND_ON, soundOn).apply()
            refreshUI()
        }

        binding.btnMusicToggle.setOnClickListener {
            musicOn = !musicOn
            prefs.edit().putBoolean(GameConstants.KEY_MUSIC_ON, musicOn).apply()
            refreshUI()
        }

        binding.btnResetScore.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Reset High Score")
                .setMessage("Are you sure you want to reset your best score?")
                .setPositiveButton("Yes") { _, _ ->
                    prefs.edit()
                        .putInt(GameConstants.KEY_HIGH_SCORE, 0)
                        .putInt(GameConstants.KEY_BONUS_SCORE, 0)
                        .apply()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        binding.btnBack.setOnClickListener {
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
    }
}
