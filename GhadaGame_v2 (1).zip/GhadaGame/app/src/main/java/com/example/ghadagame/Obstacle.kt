package com.example.ghadagame

/**
 * Obstacle.kt  (Model)
 * =====================
 * Represents one falling obstacle.
 */
data class Obstacle(
    val id: Long,          // unique id so the view can track them
    var x: Float,          // centre-X in pixels
    var y: Float,          // centre-Y in pixels
    val width: Float,
    val height: Float,
    val colorIndex: Int    // 0 or 1 → picked from obstacle colour list
)
