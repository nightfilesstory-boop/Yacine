package com.example.ghadagame

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View

/**
 * ╔═══════════════════════════════════════════════════════════════╗
 * ║  GameView.kt — Custom Canvas Renderer (MVVM View layer)      ║
 * ║                                                               ║
 * ║  Draws:  background gradient, stars, obstacles (3 types),    ║
 * ║          Ghada character, Yacine character, floor            ║
 * ║                                                               ║
 * ║  ── HOW TO REPLACE CHARACTER SPRITES ──────────────────────  ║
 * ║  1. Put PNG in res/drawable/ (e.g. ghada_sprite.png)         ║
 * ║  2. In loadBitmaps(), uncomment BitmapFactory lines          ║
 * ║  3. In drawGhada() / drawYacine(), swap drawShape calls      ║
 * ║     with: canvas.drawBitmap(bitmap, left, top, null)         ║
 * ╚═══════════════════════════════════════════════════════════════╝
 */
class GameView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null, def: Int = 0
) : View(ctx, attrs, def) {

    // ── Paints ────────────────────────────────────────────────────
    private val bgPaint     = Paint()
    private val floorPaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x33FFFFFF }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x44000000 }
    private val starPaint   = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xBBFFFFFF.toInt() }
    private val textPaint   = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color     = Color.WHITE
        textAlign = Paint.Align.CENTER
    }

    // Obstacle paints
    private val blockPaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF4444.toInt() }
    private val spikePaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF8800.toInt() }
    private val bombPaint   = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF333333.toInt() }
    private val bombFuse    = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFF00.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f
    }

    // Ghada paints
    private val gDress  = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFC77DFF.toInt() }
    private val gSkin   = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFD5B8.toInt() }
    private val gHair   = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF4A0E0E.toInt() }
    private val gEye    = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF333333.toInt() }
    private val gSmile  = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFCC4488.toInt(); style = Paint.Style.STROKE; strokeWidth = 2f; strokeCap = Paint.Cap.ROUND
    }

    // Yacine paints
    private val yShirt  = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF4361EE.toInt() }
    private val ySkin   = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFD4A373.toInt() }
    private val yHair   = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2D2D2D.toInt() }
    private val yEye    = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF222222.toInt() }
    private val yGlow   = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x44FFD700; style = Paint.Style.FILL
    }

    // ── Stars ─────────────────────────────────────────────────────
    private val stars = Array(35) {
        floatArrayOf(
            (Math.random() * 1200).toFloat(),
            (Math.random() * 2200).toFloat(),
            (Math.random() * 3f + 1f).toFloat()
        )
    }

    // ── State snapshot ────────────────────────────────────────────
    private var state: GameState? = null

    // ── Optional real bitmaps (uncomment when assets available) ──
    // private var ghadaBitmap: Bitmap? = null
    // private var yacineBitmap: Bitmap? = null
    //
    // Call this from GameActivity.onCreate() after having the assets:
    // fun loadBitmaps() {
    //     ghadaBitmap  = BitmapFactory.decodeResource(resources, R.drawable.ghada_sprite)
    //     yacineBitmap = BitmapFactory.decodeResource(resources, R.drawable.yacine_sprite)
    // }

    fun render(s: GameState) { state = s; invalidate() }

    // ─────────────────────────────────────────────────────────────
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = state ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        val d = resources.displayMetrics.density

        // ── Background gradient ───────────────────────────────────
        bgPaint.shader = LinearGradient(0f, 0f, 0f, h, s.bgTop, s.bgBottom, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, bgPaint)

        // ── Stars ─────────────────────────────────────────────────
        stars.forEach { st -> canvas.drawCircle(st[0] % w, st[1] % h, st[2], starPaint) }

        // ── Floor line ────────────────────────────────────────────
        val floorY = h - 100 * d
        canvas.drawRect(0f, floorY, w, floorY + 3f, floorPaint)

        // ── Obstacles ─────────────────────────────────────────────
        s.obstacles.forEach { obs -> drawObstacle(canvas, obs, d) }

        // ── Yacine (behind Ghada) ─────────────────────────────────
        if (s.yacineVisible) drawYacine(canvas, s.yacineX, s.yacineY, d, s.yacineBonus)

        // ── Ghada ─────────────────────────────────────────────────
        drawGhada(canvas, s.ghadaX, s.ghadaY, d)
    }

    // ─────────────────────────────────────────────────────────────
    /** Draw obstacle based on its type */
    private fun drawObstacle(canvas: Canvas, obs: Obstacle, d: Float) {
        val left   = obs.x - obs.width  / 2f
        val top    = obs.y - obs.height / 2f
        val right  = obs.x + obs.width  / 2f
        val bottom = obs.y + obs.height / 2f

        // Shadow
        canvas.drawRoundRect(RectF(left + 4, top + 4, right + 4, bottom + 4), 10f, 10f, shadowPaint)

        when (obs.type) {

            // ── TYPE 0: Block ──────────────────────────────────────
            GameConstants.OBS_TYPE_BLOCK -> {
                canvas.drawRoundRect(RectF(left, top, right, bottom), 10f, 10f, blockPaint)
                // ✦ icon
                textPaint.textSize = obs.width * 0.42f
                canvas.drawText("✦", obs.x, obs.y + textPaint.textSize * 0.35f, textPaint)
            }

            // ── TYPE 1: Spike ──────────────────────────────────────
            GameConstants.OBS_TYPE_SPIKE -> {
                val path = Path().apply {
                    moveTo(obs.x, top)                     // tip
                    lineTo(right, bottom)                  // bottom-right
                    lineTo(left, bottom)                   // bottom-left
                    close()
                }
                canvas.drawPath(path, spikePaint)
                textPaint.textSize = obs.width * 0.35f
                canvas.drawText("▲", obs.x, obs.y + textPaint.textSize * 0.3f, textPaint)
            }

            // ── TYPE 2: Bomb ───────────────────────────────────────
            GameConstants.OBS_TYPE_BOMB -> {
                val r = obs.width / 2f
                canvas.drawCircle(obs.x, obs.y, r, bombPaint)
                // Fuse line
                canvas.drawLine(obs.x, top, obs.x + r * 0.4f, top - r * 0.6f, bombFuse)
                // Spark
                val sparkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFF00.toInt() }
                canvas.drawCircle(obs.x + r * 0.4f, top - r * 0.6f, 5f * d / 3f, sparkPaint)
                textPaint.textSize = obs.width * 0.42f
                canvas.drawText("💣", obs.x, obs.y + textPaint.textSize * 0.35f, textPaint)
            }
        }
    }

    /**
     * Draw Ghada as a composed shape character.
     *
     * ── REPLACE WITH REAL IMAGE ───────────────────────────────────
     * After loading ghadaBitmap, replace this body with:
     *   ghadaBitmap?.let { bmp ->
     *       val scaled = Bitmap.createScaledBitmap(bmp, (gHalfW*2).toInt(), (gHalfH*2).toInt(), true)
     *       canvas.drawBitmap(scaled, cx - scaled.width/2f, cy - scaled.height/2f, null)
     *   }
     * ─────────────────────────────────────────────────────────────
     */
    private fun drawGhada(canvas: Canvas, cx: Float, cy: Float, d: Float) {
        val bw = 26f * d;  val bh = 38f * d
        val hr = 17f * d;  val hairR = 19f * d

        // Shadow
        canvas.drawOval(RectF(cx - bw, cy + bh / 2 - 3 * d, cx + bw, cy + bh / 2 + 7 * d), shadowPaint)
        // Dress
        canvas.drawRoundRect(RectF(cx - bw, cy - bh / 2, cx + bw, cy + bh / 2), 13f * d, 13f * d, gDress)
        // Arms
        canvas.drawRoundRect(RectF(cx - bw - 11 * d, cy - bh / 4, cx - bw + 6 * d, cy + bh / 4), 7 * d, 7 * d, gSkin)
        canvas.drawRoundRect(RectF(cx + bw - 6 * d, cy - bh / 4, cx + bw + 11 * d, cy + bh / 4), 7 * d, 7 * d, gSkin)
        // Hair (behind head)
        canvas.drawCircle(cx, cy - bh / 2 - hr + 5 * d, hairR, gHair)
        canvas.drawRoundRect(RectF(cx - hairR, cy - bh / 2 - hr * 2 + 9 * d, cx - hairR + 7 * d, cy - bh / 2), 4 * d, 4 * d, gHair)
        canvas.drawRoundRect(RectF(cx + hairR - 7 * d, cy - bh / 2 - hr * 2 + 9 * d, cx + hairR, cy - bh / 2), 4 * d, 4 * d, gHair)
        // Head
        canvas.drawCircle(cx, cy - bh / 2 - hr + 5 * d, hr, gSkin)
        // Eyes
        canvas.drawCircle(cx - 5 * d, cy - bh / 2 - hr + 3 * d, 2.5f * d, gEye)
        canvas.drawCircle(cx + 5 * d, cy - bh / 2 - hr + 3 * d, 2.5f * d, gEye)
        // Smile
        gSmile.strokeWidth = 2 * d
        canvas.drawArc(RectF(cx - 6 * d, cy - bh / 2 - hr + 5 * d, cx + 6 * d, cy - bh / 2 - hr + 14 * d), 10f, 160f, false, gSmile)
        // Sparkle on dress
        textPaint.textSize = 9 * d; textPaint.color = 0x88FFFFFF.toInt()
        canvas.drawText("✦", cx, cy + 4 * d, textPaint)
        textPaint.color = Color.WHITE
    }

    /**
     * Draw Yacine as a composed shape character.
     *
     * ── REPLACE WITH REAL IMAGE ───────────────────────────────────
     * After loading yacineBitmap, replace this body similarly to Ghada above.
     * ─────────────────────────────────────────────────────────────
     */
    private fun drawYacine(canvas: Canvas, cx: Float, cy: Float, d: Float, bonus: Boolean) {
        val bw = 24f * d;  val bh = 36f * d
        val hr = 16f * d

        // Glow ring when bonus active
        if (bonus) {
            yGlow.color = 0x66FFD700
            canvas.drawCircle(cx, cy, (bw + hr) * 1.4f, yGlow)
        }

        // Shadow
        canvas.drawOval(RectF(cx - bw, cy + bh / 2 - 3 * d, cx + bw, cy + bh / 2 + 7 * d), shadowPaint)
        // Shirt (body)
        canvas.drawRoundRect(RectF(cx - bw, cy - bh / 2, cx + bw, cy + bh / 2), 11 * d, 11 * d, yShirt)
        // Arms
        canvas.drawRoundRect(RectF(cx - bw - 10 * d, cy - bh / 4, cx - bw + 5 * d, cy + bh / 3), 7 * d, 7 * d, ySkin)
        canvas.drawRoundRect(RectF(cx + bw - 5 * d, cy - bh / 4, cx + bw + 10 * d, cy + bh / 3), 7 * d, 7 * d, ySkin)
        // Hair
        canvas.drawRoundRect(RectF(cx - hr, cy - bh / 2 - hr * 1.8f, cx + hr, cy - bh / 2 + 2 * d), 8 * d, 8 * d, yHair)
        // Head
        canvas.drawCircle(cx, cy - bh / 2 - hr + 4 * d, hr, ySkin)
        // Eyes
        canvas.drawCircle(cx - 5 * d, cy - bh / 2 - hr + 2 * d, 2.5f * d, yEye)
        canvas.drawCircle(cx + 5 * d, cy - bh / 2 - hr + 2 * d, 2.5f * d, yEye)
        // Smile  ^^
        gSmile.strokeWidth = 2 * d; gSmile.color = 0xFF226622.toInt()
        canvas.drawArc(RectF(cx - 5 * d, cy - bh / 2 - hr + 4 * d, cx + 5 * d, cy - bh / 2 - hr + 12 * d), 10f, 160f, false, gSmile)
        gSmile.color = 0xFFCC4488.toInt()

        // "Hi!" label
        textPaint.textSize = 11 * d; textPaint.color = 0xFFFFD700.toInt()
        canvas.drawText("Hi! 👋", cx, cy - bh / 2 - hr * 2.2f, textPaint)
        textPaint.color = Color.WHITE
    }
}
