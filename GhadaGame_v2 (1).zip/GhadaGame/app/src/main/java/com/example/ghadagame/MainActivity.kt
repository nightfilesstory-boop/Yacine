package com.example.ghadagame

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.animation.TranslateAnimation
import android.view.animation.Animation
import android.view.animation.AccelerateDecelerateInterpolator
import androidx.appcompat.app.AppCompatActivity
import com.example.ghadagame.databinding.ActivityMainBinding

/**
 * MainActivity.kt — Main Menu
 * Shows Ghada + Yacine avatars, high score, Start / Settings / Exit buttons.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = getSharedPreferences(GameConstants.PREFS_NAME, MODE_PRIVATE)

        refreshHighScore()

        // Ghada bobs up
        val bobGhada = TranslateAnimation(0f, 0f, 0f, -18f).apply {
            duration    = 850; repeatCount = Animation.INFINITE
            repeatMode  = Animation.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
        }
        // Yacine bobs slightly offset
        val bobYacine = TranslateAnimation(0f, 0f, -8f, 8f).apply {
            duration    = 1050; repeatCount = Animation.INFINITE
            repeatMode  = Animation.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
        }
        binding.ivGhada.startAnimation(bobGhada)
        binding.ivYacine.startAnimation(bobYacine)

        binding.btnStart.setOnClickListener {
            startActivity(Intent(this, GameActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }

        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }

        binding.btnExit.setOnClickListener {
            finishAffinity()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshHighScore()
    }

    private fun refreshHighScore() {
        val best = prefs.getInt(GameConstants.KEY_HIGH_SCORE, 0)
        binding.tvHighScore.text = getString(R.string.high_score, best)
    }
}
