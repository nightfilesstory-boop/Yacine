package com.example.ghadagame

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.ghadagame.databinding.ActivityGameBinding

/**
 * GameActivity.kt — Game Screen (MVVM View layer)
 * Manages the game loop, input, HUD updates, sound triggers,
 * and delegates ALL logic to GameViewModel.
 */
class GameActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGameBinding
    private lateinit var viewModel: GameViewModel
    private lateinit var sound: SoundManager

    private val handler      = Handler(Looper.getMainLooper())
    private val moveHandler  = Handler(Looper.getMainLooper())
    private var leftPressed  = false
    private var rightPressed = false
    private var lastTouchX   = 0f
    private var prevLevel    = 1

    private val density get() = resources.displayMetrics.density

    // ── Game loop runnable (~60fps) ───────────────────────────────
    private val loopRunnable = object : Runnable {
        override fun run() {
            viewModel.tick()
            handler.postDelayed(this, GameConstants.FRAME_MS)
        }
    }

    // ── Continuous move runnable ──────────────────────────────────
    private val moveRunnable = object : Runnable {
        override fun run() {
            if (leftPressed)  viewModel.moveLeft()
            if (rightPressed) viewModel.moveRight()
            if (leftPressed || rightPressed) moveHandler.postDelayed(this, 16L)
        }
    }

    // ─────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this)[GameViewModel::class.java]

        // Sound
        val prefs   = getSharedPreferences(GameConstants.PREFS_NAME, MODE_PRIVATE)
        val soundOn = prefs.getBoolean(GameConstants.KEY_SOUND_ON, true)
        sound = SoundManager(this).also { it.init(soundOn) }

        // Wait for layout then init physics
        binding.gameView.post {
            viewModel.init(binding.gameView.width, binding.gameView.height, density)
            startLoop()
        }

        // ── Observe state ─────────────────────────────────────────
        viewModel.state.observe(this) { s ->
            binding.tvScore.text = getString(R.string.score, s.score)
            binding.tvLevel.text = getString(R.string.level, s.level)
            binding.gameView.render(s)

            // Level-up sound + effect
            if (s.level != prevLevel) {
                prevLevel = s.level
                sound.playLevelUp()
                flashLevelUp()
            }

            // Yacine bonus
            if (s.yacineBonus) {
                sound.playBonus()
                showYacineBanner()
                showBonusPopup(s.bonusScore)
            }

            // Game over
            if (s.isGameOver) {
                stopLoop()
                sound.playHit()
                saveScores(s.score, s.bonusScore)
                Handler(Looper.getMainLooper()).postDelayed({
                    goToGameOver(s.score, s.bonusScore)
                }, 400L)
            }
        }

        // ── Pause button ──────────────────────────────────────────
        binding.btnPause.setOnClickListener {
            viewModel.togglePause()
            binding.pauseOverlay.visibility =
                if (viewModel.state.value?.isPaused == true) View.VISIBLE else View.GONE
        }
        binding.btnResume.setOnClickListener {
            viewModel.resume()
            binding.pauseOverlay.visibility = View.GONE
        }
        binding.btnQuit.setOnClickListener {
            stopLoop(); finish()
        }

        // ── Left button (hold) ────────────────────────────────────
        binding.btnLeft.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { leftPressed = true;  moveHandler.post(moveRunnable) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> leftPressed = false
            }; true
        }
        // ── Right button (hold) ───────────────────────────────────
        binding.btnRight.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { rightPressed = true; moveHandler.post(moveRunnable) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> rightPressed = false
            }; true
        }

        // ── Swipe on canvas ───────────────────────────────────────
        binding.gameView.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> lastTouchX = e.x
                MotionEvent.ACTION_MOVE -> {
                    viewModel.applySwipeDelta(e.x - lastTouchX)
                    lastTouchX = e.x
                }
            }; true
        }
    }

    // ── Lifecycle ─────────────────────────────────────────────────
    override fun onPause() {
        super.onPause()
        stopLoop()
        viewModel.state.value?.let { s ->
            if (!s.isPaused && !s.isGameOver) {
                viewModel.togglePause()
                binding.pauseOverlay.visibility = View.VISIBLE
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.state.value?.let { s -> if (!s.isGameOver) startLoop() }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopLoop()
        moveHandler.removeCallbacksAndMessages(null)
        sound.release()
    }

    // ── Helpers ───────────────────────────────────────────────────
    private fun startLoop() { handler.removeCallbacks(loopRunnable); handler.post(loopRunnable) }
    private fun stopLoop()  { handler.removeCallbacks(loopRunnable) }

    private fun flashLevelUp() {
        val flash = AlphaAnimation(0f, 1f).apply {
            duration = 300; repeatCount = 2; repeatMode = Animation.REVERSE
        }
        binding.tvLevel.startAnimation(flash)
    }

    private fun showYacineBanner() {
        binding.tvYacineMeet.visibility = View.VISIBLE
        Handler(Looper.getMainLooper()).postDelayed({
            binding.tvYacineMeet.visibility = View.GONE
        }, 1800L)
    }

    private fun showBonusPopup(bonusTotal: Int) {
        binding.tvBonusPopup.text = "✨ +${GameConstants.YACINE_BONUS_SCORE} BONUS!"
        binding.tvBonusPopup.visibility = View.VISIBLE
        val anim = AlphaAnimation(1f, 0f).apply { duration = 1400; startOffset = 400 }
        anim.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationStart(a: Animation?) {}
            override fun onAnimationRepeat(a: Animation?) {}
            override fun onAnimationEnd(a: Animation?) { binding.tvBonusPopup.visibility = View.GONE }
        })
        binding.tvBonusPopup.startAnimation(anim)
    }

    private fun saveScores(score: Int, bonus: Int) {
        val prefs = getSharedPreferences(GameConstants.PREFS_NAME, MODE_PRIVATE)
        val best  = prefs.getInt(GameConstants.KEY_HIGH_SCORE, 0)
        if (score + bonus > best)
            prefs.edit().putInt(GameConstants.KEY_HIGH_SCORE, score + bonus).apply()
    }

    private fun goToGameOver(score: Int, bonus: Int) {
        val i = Intent(this, GameOverActivity::class.java)
        i.putExtra(GameConstants.EXTRA_SCORE, score)
        i.putExtra(GameConstants.EXTRA_BONUS, bonus)
        startActivity(i)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }
}
