package com.example.ghadagame

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.random.Random

/**
 * ╔═══════════════════════════════════════════════╗
 * ║           GameViewModel.kt                   ║
 * ║  MVVM ViewModel — owns ALL game logic.       ║
 * ║  Activities only READ LiveData and call      ║
 * ║  public methods; they never mutate state.    ║
 * ╚═══════════════════════════════════════════════╝
 */
class GameViewModel : ViewModel() {

    private val _state = MutableLiveData(GameState())
    val state: LiveData<GameState> = _state

    // ── Screen / physics cached values ───────────────────────────
    private var screenW  = 0f
    private var screenH  = 0f
    private var density  = 1f

    // Character half-sizes in px
    private var gHalfW   = 0f; private var gHalfH   = 0f   // Ghada
    private var yHalfW   = 0f; private var yHalfH   = 0f   // Yacine
    private var oHalfW   = 0f; private var oHalfH   = 0f   // Obstacle

    // Speeds in px/frame
    private var obstacleSpeed   = 0f
    private var ghadaSpeed      = 0f

    // Spawn timing
    private var spawnIntervalFrames  = 0
    private var framesSinceLastSpawn = 0
    private var nextObstacleId       = 0L

    // Yacine logic
    private var obstaclesToNextYacine = GameConstants.YACINE_APPEAR_EVERY
    private var yacineTargetX = 0f

    // ── One-time init ─────────────────────────────────────────────
    fun init(w: Int, h: Int, d: Float) {
        if (screenW > 0f) return
        screenW = w.toFloat()
        screenH = h.toFloat()
        density = d

        fun dp(v: Float) = v * d

        gHalfW = dp(GameConstants.GHADA_WIDTH_DP)  / 2f
        gHalfH = dp(GameConstants.GHADA_HEIGHT_DP) / 2f
        yHalfW = dp(GameConstants.YACINE_WIDTH_DP)  / 2f
        yHalfH = dp(GameConstants.YACINE_HEIGHT_DP) / 2f
        oHalfW = dp(GameConstants.OBS_WIDTH_DP)  / 2f
        oHalfH = dp(GameConstants.OBS_HEIGHT_DP) / 2f

        obstacleSpeed = dp(GameConstants.BASE_SPEED_DP)
        ghadaSpeed    = dp(GameConstants.GHADA_SPEED_DP)

        spawnIntervalFrames = (GameConstants.BASE_SPAWN_MS / GameConstants.FRAME_MS).toInt()

        val ghadaStartX = screenW / 2f
        val ghadaStartY = screenH - dp(130f)
        yacineTargetX   = -200f   // off-screen

        val bg = GameConstants.LEVEL_BACKGROUNDS[0]
        _state.value = GameState(
            ghadaX   = ghadaStartX,
            ghadaY   = ghadaStartY,
            yacineX  = -200f,
            yacineY  = ghadaStartY,
            bgTop    = bg.first,
            bgBottom = bg.second
        )
    }

    // ── Main game tick (called every ~16ms) ───────────────────────
    fun tick() {
        val s = _state.value ?: return
        if (s.isPaused || s.isGameOver) return

        // ── Move obstacles ────────────────────────────────────────
        val moved = s.obstacles.map { it.copy(y = it.y + obstacleSpeed) }

        // ── Remove off-screen + score ─────────────────────────────
        var gained = 0
        val active = moved.filter { obs ->
            if (obs.y - oHalfH > screenH) { gained += GameConstants.SCORE_PER_OBSTACLE; false }
            else true
        }

        // ── Spawn new obstacle ────────────────────────────────────
        framesSinceLastSpawn++
        val newObstacles = active.toMutableList()
        if (framesSinceLastSpawn >= spawnIntervalFrames) {
            framesSinceLastSpawn = 0
            val spawnX = oHalfW + Random.nextFloat() * (screenW - oHalfW * 2f)
            newObstacles.add(Obstacle(
                id     = nextObstacleId++,
                x      = spawnX,
                y      = -oHalfH,
                width  = oHalfW * 2f,
                height = oHalfH * 2f,
                type   = Random.nextInt(3)   // BLOCK / SPIKE / BOMB
            ))
        }

        // ── Collision (AABB with 80% factor for fairness) ─────────
        val hit = newObstacles.any { obs ->
            abs(obs.x - s.ghadaX) < (oHalfW + gHalfW) * 0.80f &&
            abs(obs.y - s.ghadaY) < (oHalfH + gHalfH) * 0.80f
        }

        val newScore = s.score + gained
        val newLevel = calcLevel(newScore)
        val bg       = GameConstants.LEVEL_BACKGROUNDS[(newLevel - 1).coerceIn(0, GameConstants.LEVEL_BACKGROUNDS.size - 1)]

        updateSpeedForLevel(newLevel)

        // ── Yacine logic ──────────────────────────────────────────
        var yacineVisible = s.yacineVisible
        var yacineX = s.yacineX
        var bonusGained = 0
        var yacineBonus = false

        if (gained > 0) {
            obstaclesToNextYacine -= gained
            if (obstaclesToNextYacine <= 0) {
                // Spawn Yacine on opposite side of Ghada
                yacineVisible = true
                yacineX = if (s.ghadaX < screenW / 2f) screenW - yHalfW * 4 else yHalfW * 4
                yacineTargetX = s.ghadaX
                obstaclesToNextYacine = GameConstants.YACINE_APPEAR_EVERY
            }
        }

        if (yacineVisible) {
            // Yacine drifts toward Ghada
            yacineTargetX = s.ghadaX
            yacineX += (yacineTargetX - yacineX) * GameConstants.YACINE_FOLLOW_SPEED

            // Bonus if close enough to Ghada
            val bonusRange = GameConstants.YACINE_BONUS_RANGE_DP * density
            val dist = hypot(yacineX - s.ghadaX, s.yacineY - s.ghadaY)
            if (dist < bonusRange) {
                bonusGained = GameConstants.YACINE_BONUS_SCORE
                yacineVisible = false
                yacineX = -200f
                yacineBonus = true
            }
        }

        _state.value = s.copy(
            score         = newScore,
            bonusScore    = s.bonusScore + bonusGained,
            level         = newLevel,
            obstacles     = newObstacles,
            isGameOver    = hit,
            yacineX       = yacineX,
            yacineVisible = yacineVisible,
            yacineBonus   = yacineBonus,
            bgTop         = bg.first,
            bgBottom      = bg.second
        )
    }

    // ── Player input ──────────────────────────────────────────────
    fun moveLeft() {
        val s = _state.value ?: return
        if (s.isPaused || s.isGameOver) return
        _state.value = s.copy(ghadaX = (s.ghadaX - ghadaSpeed).coerceAtLeast(gHalfW))
    }

    fun moveRight() {
        val s = _state.value ?: return
        if (s.isPaused || s.isGameOver) return
        _state.value = s.copy(ghadaX = (s.ghadaX + ghadaSpeed).coerceAtMost(screenW - gHalfW))
    }

    fun applySwipeDelta(dx: Float) {
        val s = _state.value ?: return
        if (s.isPaused || s.isGameOver) return
        _state.value = s.copy(ghadaX = (s.ghadaX + dx).coerceIn(gHalfW, screenW - gHalfW))
    }

    // ── Pause ─────────────────────────────────────────────────────
    fun togglePause()  { _state.value = _state.value?.let { it.copy(isPaused = !it.isPaused) } }
    fun resume()       { _state.value = _state.value?.copy(isPaused = false) }

    // ── Helpers ───────────────────────────────────────────────────
    private fun calcLevel(score: Int): Int =
        ((score / GameConstants.OBSTACLES_PER_LEVEL) + 1).coerceAtMost(GameConstants.MAX_LEVEL)

    private fun updateSpeedForLevel(level: Int) {
        fun dp(v: Float) = v * density
        obstacleSpeed = dp(GameConstants.BASE_SPEED_DP) + (level - 1) * dp(GameConstants.SPEED_INC_DP)
        val ms = (GameConstants.BASE_SPAWN_MS - (level - 1) * GameConstants.SPAWN_DEC_MS)
                    .coerceAtLeast(GameConstants.MIN_SPAWN_MS)
        spawnIntervalFrames = (ms / GameConstants.FRAME_MS).toInt().coerceAtLeast(1)
    }
}
