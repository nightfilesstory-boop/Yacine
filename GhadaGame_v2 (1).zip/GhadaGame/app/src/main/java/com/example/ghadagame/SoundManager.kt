package com.example.ghadagame

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool

/**
 * SoundManager.kt
 * ================
 * Handles all sound effects. Uses SoundPool for low-latency playback.
 *
 * ── HOW TO ADD REAL SOUNDS ───────────────────────────────────────
 * 1. Place .ogg or .mp3 files in res/raw/:
 *      res/raw/sfx_dodge.ogg      (obstacle avoided)
 *      res/raw/sfx_hit.ogg        (player hit / game over)
 *      res/raw/sfx_bonus.ogg      (Yacine bonus collected)
 *      res/raw/sfx_levelup.ogg    (level changed)
 * 2. In loadSounds(), uncomment the SoundPool.load() lines.
 * 3. Delete the placeholder log lines.
 * ─────────────────────────────────────────────────────────────────
 */
class SoundManager(private val context: Context) {

    private var soundPool: SoundPool? = null
    private var soundEnabled = true

    // Sound IDs (0 = not loaded)
    private var sfxDodge   = 0
    private var sfxHit     = 0
    private var sfxBonus   = 0
    private var sfxLevelUp = 0

    fun init(soundOn: Boolean) {
        soundEnabled = soundOn
        if (!soundOn) return

        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        soundPool = SoundPool.Builder()
            .setMaxStreams(4)
            .setAudioAttributes(attrs)
            .build()

        // ── UNCOMMENT WHEN AUDIO FILES ARE ADDED ─────────────────
        // sfxDodge   = soundPool!!.load(context, R.raw.sfx_dodge,   1)
        // sfxHit     = soundPool!!.load(context, R.raw.sfx_hit,     1)
        // sfxBonus   = soundPool!!.load(context, R.raw.sfx_bonus,   1)
        // sfxLevelUp = soundPool!!.load(context, R.raw.sfx_levelup, 1)
    }

    fun playDodge()   { play(sfxDodge)   }
    fun playHit()     { play(sfxHit)     }
    fun playBonus()   { play(sfxBonus)   }
    fun playLevelUp() { play(sfxLevelUp) }

    private fun play(id: Int) {
        if (!soundEnabled || id == 0) return
        soundPool?.play(id, 1f, 1f, 0, 0, 1f)
    }

    fun setSoundEnabled(on: Boolean) { soundEnabled = on }

    fun release() { soundPool?.release(); soundPool = null }
}
