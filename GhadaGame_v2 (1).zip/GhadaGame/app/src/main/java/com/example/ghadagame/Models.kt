package com.example.ghadagame

/**
 * Models.kt  — all data classes (MVVM Model layer)
 */

/** One falling obstacle on screen */
data class Obstacle(
    val id: Long,
    var x: Float,
    var y: Float,
    val width: Float,
    val height: Float,
    val type: Int          // OBS_TYPE_BLOCK / SPIKE / BOMB
)

/** Full snapshot of game state — emitted by ViewModel as LiveData */
data class GameState(
    val score: Int              = 0,
    val bonusScore: Int         = 0,
    val level: Int              = 1,
    val isPaused: Boolean       = false,
    val isGameOver: Boolean     = false,

    // Ghada
    val ghadaX: Float           = 0f,
    val ghadaY: Float           = 0f,

    // Yacine
    val yacineX: Float          = -200f,   // off-screen initially
    val yacineY: Float          = 0f,
    val yacineVisible: Boolean  = false,
    val yacineBonus: Boolean    = false,   // pulse true when bonus triggered

    val obstacles: List<Obstacle> = emptyList(),

    // Current background colours
    val bgTop: Int              = 0xFF1B4332.toInt(),
    val bgBottom: Int           = 0xFF40916C.toInt()
)
