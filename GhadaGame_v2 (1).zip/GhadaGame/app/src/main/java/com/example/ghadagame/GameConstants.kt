package com.example.ghadagame

/**
 * ╔══════════════════════════════════════════════════╗
 * ║           GameConstants.kt                      ║
 * ║  Central tuning panel — change values here to   ║
 * ║  adjust speed, difficulty, scoring, etc.        ║
 * ╚══════════════════════════════════════════════════╝
 */
object GameConstants {

    // ── Characters ───────────────────────────────────────────────
    const val GHADA_WIDTH_DP      = 54f
    const val GHADA_HEIGHT_DP     = 76f
    const val GHADA_SPEED_DP      = 13f     // pixels/tick when button held

    const val YACINE_WIDTH_DP     = 54f
    const val YACINE_HEIGHT_DP    = 76f
    const val YACINE_FOLLOW_SPEED = 0.04f   // 0–1: how fast Yacine closes gap to Ghada
    const val YACINE_BONUS_SCORE  = 5       // bonus when Ghada "meets" Yacine
    const val YACINE_APPEAR_EVERY = 20      // every N avoided obstacles Yacine appears
    const val YACINE_BONUS_RANGE_DP = 70f   // px distance to trigger bonus

    // ── Obstacles ────────────────────────────────────────────────
    const val OBS_WIDTH_DP        = 52f
    const val OBS_HEIGHT_DP       = 52f
    const val BASE_SPEED_DP       = 6f
    const val SPEED_INC_DP        = 1.8f    // added per level
    const val BASE_SPAWN_MS       = 1200L
    const val SPAWN_DEC_MS        = 100L
    const val MIN_SPAWN_MS        = 380L

    // ── Obstacle types ───────────────────────────────────────────
    const val OBS_TYPE_BLOCK      = 0       // plain square
    const val OBS_TYPE_SPIKE      = 1       // triangle/spike shape
    const val OBS_TYPE_BOMB       = 2       // circle bomb

    // ── Levels ───────────────────────────────────────────────────
    const val OBSTACLES_PER_LEVEL = 10      // score threshold for level-up
    const val MAX_LEVEL           = 8

    // ── Scoring ──────────────────────────────────────────────────
    const val SCORE_PER_OBSTACLE  = 1

    // ── Frame timing ─────────────────────────────────────────────
    const val FRAME_MS            = 16L     // ~60fps

    // ── SharedPreferences ────────────────────────────────────────
    const val PREFS_NAME          = "ghada_prefs"
    const val KEY_HIGH_SCORE      = "high_score"
    const val KEY_BONUS_SCORE     = "bonus_total"
    const val KEY_SOUND_ON        = "sound_on"
    const val KEY_MUSIC_ON        = "music_on"

    // ── Intent extras ────────────────────────────────────────────
    const val EXTRA_SCORE         = "extra_score"
    const val EXTRA_BONUS         = "extra_bonus"

    // ── Background themes per level ──────────────────────────────
    // Each entry = Pair(topColor, bottomColor) as ARGB ints
    val LEVEL_BACKGROUNDS = arrayOf(
        Pair(0xFF1B4332.toInt(), 0xFF40916C.toInt()),  // L1: Forest (green)
        Pair(0xFF1A1A2E.toInt(), 0xFF16213E.toInt()),  // L2: City (dark blue)
        Pair(0xFF0096C7.toInt(), 0xFF90E0EF.toInt()),  // L3: Sky (light blue)
        Pair(0xFFFF6B35.toInt(), 0xFFFFD166.toInt()),  // L4: Sunset (orange)
        Pair(0xFF03045E.toInt(), 0xFF7209B7.toInt()),  // L5: Space (deep purple)
        Pair(0xFF2D132C.toInt(), 0xFFEE4540.toInt()),  // L6: Crimson (red)
        Pair(0xFF162447.toInt(), 0xFF1F4068.toInt()),  // L7: Ocean (teal)
        Pair(0xFF1A0000.toInt(), 0xFFFF6B35.toInt()),  // L8: Fire (orange-red)
    )
}
