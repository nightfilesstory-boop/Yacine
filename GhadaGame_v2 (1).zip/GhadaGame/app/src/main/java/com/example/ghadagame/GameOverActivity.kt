package com.example.ghadagame

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.TranslateAnimation
import android.view.animation.Animation
import androidx.appcompat.app.AppCompatActivity
import com.example.ghadagame.databinding.ActivityGameOverBinding

/**
 * GameOverActivity.kt
 * ====================
 * Displays final score, bonus score, best score, and optional NEW RECORD banner.
 */
class GameOverActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGameOverBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameOverBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val score  = intent.getIntExtra(GameConstants.EXTRA_SCORE, 0)
        val bonus  = intent.getIntExtra(GameConstants.EXTRA_BONUS, 0)
        val total  = score + bonus
        val prefs  = getSharedPreferences(GameConstants.PREFS_NAME, MODE_PRIVATE)
        val best   = prefs.getInt(GameConstants.KEY_HIGH_SCORE, 0)

        binding.tvFinalScore.text = getString(R.string.your_score, score)
        binding.tvBonusScore.text = "Bonus: +$bonus"
        binding.tvBestScore.text  = getString(R.string.high_score, best)

        if (total >= best && total > 0) {
            binding.tvNewRecord.visibility = View.VISIBLE
            val shake = TranslateAnimation(-10f, 10f, 0f, 0f).apply {
                duration = 80; repeatCount = 5; repeatMode = Animation.REVERSE
            }
            binding.tvNewRecord.startAnimation(shake)
        }

        binding.btnPlayAgain.setOnClickListener {
            startActivity(Intent(this, GameActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }

        binding.btnMainMenu.setOnClickListener {
            val i = Intent(this, MainActivity::class.java)
            i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(i)
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }
    }
}
