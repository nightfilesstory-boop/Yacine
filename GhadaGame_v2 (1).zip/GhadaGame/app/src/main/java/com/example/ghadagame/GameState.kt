package com.example.ghadagame

/**
 * GameState.kt  (MVVM – Model layer)
 * ===================================
 * Pure data holder — no Android dependencies.
 * GameViewModel observes / mutates this.
 */
data class GameState(
    val score: Int        = 0,
    val level: Int        = 1,
    val isPaused: Boolean = false,
    val isGameOver: Boolean = false,
    val ghadaX: Float     = 0f,   // centre-X of Ghada in pixels
    val ghadaY: Float     = 0f,   // centre-Y of Ghada in pixels
    val obstacles: List<Obstacle> = emptyList()
)
